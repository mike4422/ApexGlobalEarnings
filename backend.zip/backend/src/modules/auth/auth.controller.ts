import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../../config/prisma';
import { env } from '../../config/env';
import { v4 as uuidv4 } from 'uuid';

export async function register(req: Request, res: Response) {
  try {
    const { name, email, password, ref } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      return res.status(409).json({ error: 'Email already in use' });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    let referredById: string | undefined;
    if (ref) {
      const refUser = await prisma.user.findUnique({
        where: { referralCode: ref },
      });
      if (refUser) referredById = refUser.id;
    }

    const referralCode = `APEX${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

    const user = await prisma.user.create({
      data: {
        name,
        email,
        passwordHash,
        referralCode,
        referredById,
      },
    });

    const jti = uuidv4();
    const token = jwt.sign(
      { userId: user.id, role: user.role, jti },
      env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    await prisma.session.create({
      data: {
        userId: user.id,
        jwtId: jti,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return res.status(201).json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        referralCode: user.referralCode,
      },
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) return res.status(404).json({ error: 'User not found' });

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(400).json({ error: 'Incorrect password' });

    const jti = uuidv4();
    const token = jwt.sign(
      { userId: user.id, role: user.role, jti },
      env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    await prisma.session.create({
      data: {
        userId: user.id,
        jwtId: jti,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        referralCode: user.referralCode,
      },
    });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function me(req: any, res: Response) {
  const user = await prisma.user.findUnique({
    where: { id: req.user.id },
    select: {
      id: true,
      email: true,
      name: true,
      role: true,
      referralCode: true,
      createdAt: true,
      balanceCents: true,
    },
  });
  return res.json({ user });
}
