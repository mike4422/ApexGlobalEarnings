import { Response } from 'express';
import { prisma } from '../../config/prisma';
import { AuthRequest } from '../../middleware/auth';

export async function createInvestment(req: AuthRequest, res: Response) {
  try {
    const { planId, amount } = req.body;
    const plan = await prisma.plan.findUnique({ where: { id: planId } });
    if (!plan || !plan.isActive) {
      return res.status(400).json({ error: 'Invalid plan' });
    }

    const amountCents = Math.round(amount * 100);
    if (amountCents < plan.minAmountCents) {
      return res.status(400).json({ error: 'Amount below plan minimum' });
    }

    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
    });
    if (!user || user.balanceCents < amountCents) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.durationDays);

    const [investment] = await prisma.$transaction([
      prisma.investment.create({
        data: {
          userId: user.id,
          planId: plan.id,
          amountCents,
          endDate,
        },
      }),
      prisma.user.update({
        where: { id: user.id },
        data: {
          balanceCents: { decrement: amountCents },
        },
      }),
      prisma.transaction.create({
        data: {
          userId: user.id,
          type: 'DEPOSIT',
          asset: 'USDT',
          amountCents,
          status: 'COMPLETED',
          meta: { reason: 'Investment funding' },
        },
      }),
    ]);

    return res.status(201).json({ investment });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function myInvestments(req: AuthRequest, res: Response) {
  const investments = await prisma.investment.findMany({
    where: { userId: req.user!.id },
    include: { plan: true },
    orderBy: { createdAt: 'desc' },
  });

  return res.json({ investments });
}

export async function summary(req: AuthRequest, res: Response) {
  const [totalInvested, activeInvestments, totalProfit] = await Promise.all([
    prisma.investment.aggregate({
      _sum: { amountCents: true },
      where: { userId: req.user!.id },
    }),
    prisma.investment.count({
      where: { userId: req.user!.id, status: 'ACTIVE' },
    }),
    prisma.transaction.aggregate({
      _sum: { amountCents: true },
      where: {
        userId: req.user!.id,
        type: 'INVESTMENT_RETURN',
        status: 'COMPLETED',
      },
    }),
  ]);

  return res.json({
    totalInvestedCents: totalInvested._sum.amountCents ?? 0,
    activeInvestments,
    totalProfitCents: totalProfit._sum.amountCents ?? 0,
  });
}
