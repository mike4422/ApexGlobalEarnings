import { Router } from 'express';
import {
  createInvestment,
  myInvestments,
  summary,
} from './investments.controller';
import { requireAuth } from '../../middleware/auth';

export const investmentsRouter = Router();

investmentsRouter.post('/', requireAuth, createInvestment);
investmentsRouter.get('/my', requireAuth, myInvestments);
investmentsRouter.get('/summary', requireAuth, summary);
