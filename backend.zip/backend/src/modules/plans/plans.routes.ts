import { Router } from 'express';
import { listPlans } from './plans.controller';
export const plansRouter = Router();

plansRouter.get('/', listPlans);
