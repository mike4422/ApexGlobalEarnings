import { Request, Response } from 'express';
import { prisma } from '../../config/prisma';

export async function listPlans(req: Request, res: Response) {
  const plans = await prisma.plan.findMany({ where: { isActive: true } });
  return res.json({ plans });
}
