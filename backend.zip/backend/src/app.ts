import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import { env } from './config/env';
import { authRouter } from './modules/auth/auth.routes';
import { plansRouter } from './modules/plans/plans.routes';
import { investmentsRouter } from './modules/investments/investments.routes';
import { referralsRouter } from './modules/referrals/referrals.routes';
import { walletRouter } from './modules/wallet/wallet.routes';
import { adminRouter } from './modules/admin/admin.routes';
import { pricesRouter } from './modules/prices/prices.routes';
import { errorHandler } from './middleware/errorHandler';

export const app = express();

app.use(helmet());
app.use(
  cors({
    origin: env.CORS_ORIGIN,
    credentials: true,
  })
);
app.use(morgan('dev'));
app.use(express.json());
app.use(cookieParser());

// routes
app.use('/api/auth', authRouter);
app.use('/api/plans', plansRouter);
app.use('/api/investments', investmentsRouter);
app.use('/api/referrals', referralsRouter);
app.use('/api/wallet', walletRouter);
app.use('/api/admin', adminRouter);
app.use('/api/prices', pricesRouter);

// error
app.use(errorHandler);
