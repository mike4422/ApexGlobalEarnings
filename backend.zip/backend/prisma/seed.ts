import { PrismaClient, UserRole } from '@prisma/client';
import bcrypt from 'bcryptjs';
const prisma = new PrismaClient();

async function main() {
  const adminEmail = 'admin@apexglobalearnings.com';
  const passwordHash = await bcrypt.hash('AdminStrongP@ss1', 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      passwordHash,
      role: UserRole.ADMIN,
      referralCode: 'APEXADMIN',
      name: 'Platform Admin',
    },
  });

  await prisma.settings.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1, level1Bps: 500, level2Bps: 200 },
  });

  await prisma.plan.createMany({
    data: [
      {
        name: 'Bronze',
        slug: 'bronze',
        minAmountCents: 10000,
        dailyRoiBps: 100,
        durationDays: 15,
      },
      {
        name: 'Silver',
        slug: 'silver',
        minAmountCents: 50000,
        dailyRoiBps: 150,
        durationDays: 20,
      },
      {
        name: 'Gold',
        slug: 'gold',
        minAmountCents: 100000,
        dailyRoiBps: 200,
        durationDays: 25,
      },
      {
        name: 'VIP',
        slug: 'vip',
        minAmountCents: 250000,
        dailyRoiBps: 250,
        durationDays: 30,
      },
    ],
    skipDuplicates: true,
  });

  console.log('Seed completed. Admin:', admin.email);
}

main().finally(() => prisma.$disconnect());
